/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import com.macfaq.net.www.protocol.chargen.Handler;

/*
 *
 * @author hailiang194
 */
public class ChargenURLConnectionHandlerMain {
    public static void main(String[] args) {
        Handler handler = new Handler();
        System.out.println(handler.getDefaultPort());
    }
}
