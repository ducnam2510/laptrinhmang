package Main;


import com.macfaq.io.FiniteInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hailiang194
 */
public class FiniteInputStreamMain {
    public static void main(String[] args) throws IOException {
        byte[] bytes = {0, 1, 2};
        FiniteInputStream stream = new FiniteInputStream(new ByteArrayInputStream(bytes));
        System.out.println(stream.available());
    }
}
