/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import java.net.MalformedURLException;
import java.net.URL;
import sun.net.www.protocol.mailto.Handler;

/**
 *
 * @author hailiang194
 */
public class HandlerMain {
    public static void main(String[] args) throws MalformedURLException {
        Handler handler = new Handler();
        handler.parseURL(new URL("https://www.gmail.com/"), "hailuongthe2000@gmail", 0, 0);
    }
}
